﻿using System;
using System.Text.RegularExpressions;

namespace Palindrome_Checker
{
    class Program
    {
        public static void Main()
        {
            StringWorks stringWorks = new StringWorks();

            stringWorks.Check("abcba", true);
            stringWorks.Check("abcde", false);
            stringWorks.Check("Mr owl ate my metal worm", true);
            stringWorks.Check("Never Odd Or Even", true);
            stringWorks.Check("Never Even Or Odd", false);
        }
    }

    class StringWorks
    {
        // Implement a palindrome checker to make the following test cases pass. This starter code is in C# but you are welcome to write your solution in any language
        bool IsPalindrome(string s)
        {
            s = s.ToLower(); 
            Regex rgx = new Regex(@"[\s\W]+");
            s = rgx.Replace(s, "");

            var reverseString = Reverse(s);

            return s == reverseString;
        }

        public string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }

        public void Check(string s, bool shouldBePalindrome)
        {
            Console.WriteLine(IsPalindrome(s) == shouldBePalindrome ? "pass" : "FAIL");
        }
    }
}
